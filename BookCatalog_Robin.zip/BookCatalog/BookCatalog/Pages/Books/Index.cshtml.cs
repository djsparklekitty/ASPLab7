using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BookCatalog.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BookCatalog.Pages.Books
{
    public class IndexModel : PageModel
    {
        private readonly BookCatalog.Models.BookContext _context;

        public IndexModel(BookCatalog.Models.BookContext context)
        {
            _context = context;
        }

        public IList<Book> Book { get;set; }
        public SelectList Authors;
        public string BookAuthor { get; set; }

        public async Task OnGetAsync(string BookAuthor, string searchString)
        {
            // Use LINQ to get list of genres.
            IQueryable<string> authorQuery = from b in _context.Book
                                            orderby b.Author
                                            select b.Author;

            var books = from b in _context.Book
                         select b;

            if (!String.IsNullOrEmpty(searchString))
            {
                books = books.Where(s => s.Title.Contains(searchString));
            }

            if (!String.IsNullOrEmpty(BookAuthor))
            {
                books = books.Where(x => x.Author == BookAuthor);
            }
            Authors = new SelectList(await authorQuery.Distinct().ToListAsync());
            Book = await books.ToListAsync();
        }
    }
}
